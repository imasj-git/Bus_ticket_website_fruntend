function Register() {


    return <>
        this is Register page
    </>
}

export default Register