function Home() {

    return <>
        <body class="bg-gray-100 text-gray-800">

            <header class="bg-blue-600 text-white shadow">
                <div class="container mx-auto flex justify-between items-center py-4 px-6">

                    <div class="text-2xl font-bold">
                        <a href="#">Logo</a>
                    </div>


                    <nav class="hidden md:flex space-x-6">
                        <a href="#" class="hover:text-gray-200">Home</a>
                        <a href="#" class="hover:text-gray-200">Blogs</a>
                        <a href="#" class="hover:text-gray-200">Contact Us</a>
                        <a href="#" class="hover:text-gray-200">About Us</a>
                        <a href="#" class="hover:text-gray-200">Manage Tickets</a>
                    </nav>


                    <div class="relative hidden md:block">
                        <input
                            type="text"
                            placeholder="Search..."
                            class="w-full py-2 px-4 rounded-md text-black focus:outline-none"
                        />
                        <button class="absolute right-0 top-0 mt-2 mr-2 text-gray-600 hover:text-gray-800">
                            🔍
                        </button>
                    </div>


                    <div class="flex space-x-4">
                        <a href="#" class="bg-white text-blue-600 px-4 py-2 rounded hover:bg-blue-100">Login</a>
                        <a href="#" class="bg-blue-500 px-4 py-2 rounded hover:bg-blue-700">Sign Up</a>
                    </div>


                    <button class="md:hidden text-2xl">
                        ☰
                    </button>
                </div>
            </header>

            <section class="bg-blue-500 text-white py-20">
                <div class="container mx-auto text-center">
                    <h1 class="text-4xl font-bold mb-4">Book Your Bus Tickets Hassle-Free</h1>
                    <p class="text-lg mb-8">Find and book bus tickets quickly and conveniently. Travel smarter with us!</p>
                    <a href="#" class="bg-white text-blue-600 px-6 py-3 rounded hover:bg-gray-200">Get Started</a>
                </div>
            </section>

            <section class="py-16">
                <div class="container mx-auto">
                    <h2 class="text-3xl font-bold text-center mb-8">Why Choose Us</h2>
                    <div class="grid md:grid-cols-3 gap-8">
                        <div class="bg-white shadow p-6 rounded">
                            <h3 class="text-xl font-semibold mb-2">Easy Booking</h3>
                            <p>Book tickets online quickly with our user-friendly platform.</p>
                        </div>
                        <div class="bg-white shadow p-6 rounded">
                            <h3 class="text-xl font-semibold mb-2">Affordable Prices</h3>
                            <p>Get the best deals and save money on your trips.</p>
                        </div>
                        <div class="bg-white shadow p-6 rounded">
                            <h3 class="text-xl font-semibold mb-2">24/7 Support</h3>
                            <p>Our team is always here to assist you with any queries.</p>
                        </div>
                    </div>
                </div>
            </section>


            <footer class="bg-blue-600 text-white py-6">
                <div class="container mx-auto text-center">
                    <p>&copy; 2024 Bus Ticket Booking. All rights reserved.</p>
                    <nav class="flex justify-center space-x-4 mt-4">
                        <a href="#" class="hover:text-gray-200">Privacy Policy</a>
                        <a href="#" class="hover:text-gray-200">Terms of Service</a>
                        <a href="#" class="hover:text-gray-200">Contact Us</a>
                    </nav>
                </div>
            </footer>
        </body>
    </>
}

export default Home